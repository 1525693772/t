Better_optimal version 1.1
EN
Updated:

1.Rebalance the generation ratios of objects
2.Added compatibility with Undead Legacy mod , see <Version> folder
3.Minor error fixes
4.Large code optimization (from 550 lines to 150)

By default, the mod has a vanilla version of biomes.xml .
If you want to use better_optimal with the undead legacy mod,
  copy biomes_compatibility_Undead_Legacy.xml from <Version> folder to <Config> folder and rename it to biomes.xml with file replacement.
To return the vanilla version, do the same with the biomes_compatibility_Vanilla.xml file

Future plans - adapt better_optimal for all popular global mods.
Contact discord https://discord.gg/CDrbNTvQqh

RU 
Обновлено:

1.Ребаланс коэффициентов генерации обьектов
2.Добавлена совместимость с модом Undead Legacy , смотри папку <Version>
3.Исправление ошибок 
4.Большая оптимизация кода (с 550 строк до 150)


По умолчанию мод имеет ванильную версию biomes.xml .
Если вы хотите использовать better_optimal с модом undead legacy,
  скопируйте biomes_compatibility_Undead_Legacy.xml из папки <Version> в папку <Config> и переименуйте его в biomes.xml с заменой файлов.
Чтобы вернуть ванильную версию, сделайте те же самые действия с файлом biomes_compatibility_Vanilla.xml

Планы на будущее - адаптировать better_optimal для многих популярных глобальных модов.
Связь дискорд https://discord.gg/CDrbNTvQqh